class Block {
    constructor(
        private data: string
    ) { }
    static hello() {
        return "hi";
    }
}